<?php $__env->startSection('content'); ?>
    <board token="<?php echo e($token); ?>" playercolor="<?php echo e($playerColor); ?>"></board>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript">
		const app = new Vue({
		    el: '#app',
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Games\EasyChess\resources\views/home.blade.php ENDPATH**/ ?>