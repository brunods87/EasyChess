

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-12">
				Waiting for opponent...
			</div>
		</div>
	</div>

	<script type="text/javascript">
		var interval = setInterval(function(){
			$.ajax({
				type: 'POST',
				url: '<?php echo e(route('requestGame')); ?>',
				data: {token: '<?php echo e($token); ?>' },
			}).done(function(response){
				var message = response;
				if (message){
					location.href="<?php echo e(route('home', ['token' => $token])); ?>";
				}
			});
		}, 1000);
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bruno\Documents\Programacao\Games\EasyChess\resources\views/limbo.blade.php ENDPATH**/ ?>